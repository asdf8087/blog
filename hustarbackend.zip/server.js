import express from 'express';
import path from "path";
import ejs from 'ejs';

const HOST = '0.0.0.0';
const PORT = 3000;
const app = new express();  
app.use(express.static('static'));
app.set('view engine','ejs');
app.listen(3000, () => {
    console.log(`http://${HOST}:${PORT}`);

    app.get('/index', (request, response) => 
        response.render('index', {
            title:'메인',
            user:{name : 'HuStar', //객체전달
                location : 'DCU'},
            data:[  //배열전달
                '첫 번째데이터',
                '다음 데이터',
                '마지막데이터'
            ]
        })
    );
        

    app.get('/about', (request, response) => 
        response.render('about',{title:'about'}));

    app.get('/contact', (request, response) => 
        response.render('contact',{title:'연락처'}));
    
    app.get('/post/:id?', (request, response) => 
    response.render('post',{
        title:'포스트',
        id: request.params.id
    }
    ));   

});
